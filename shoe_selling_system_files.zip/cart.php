<?php require 'config.php'; require_login();
if(!isset($_SESSION['cart'])) $_SESSION['cart']=[];
if($_SERVER['REQUEST_METHOD']==='POST'){verify_csrf();$id=(int)($_POST['product_id']??0);$action=$_POST['action']??'';
if($action==='add'){$q=max(1,(int)($_POST['quantity']??1));$s=$pdo->prepare("SELECT stock FROM products WHERE id=?");$s->execute([$id]);$p=$s->fetch();if($p){$_SESSION['cart'][$id]=min((int)$p['stock'],($_SESSION['cart'][$id]??0)+$q);}}
if($action==='remove') unset($_SESSION['cart'][$id]);
header('Location: cart.php');exit;}
$items=[];$total=0;
if($_SESSION['cart']){$ids=array_keys($_SESSION['cart']);$marks=implode(',',array_fill(0,count($ids),'?'));$s=$pdo->prepare("SELECT * FROM products WHERE id IN ($marks)");$s->execute($ids);foreach($s as $p){$q=min((int)$p['stock'],(int)$_SESSION['cart'][$p['id']]);if($q<1){unset($_SESSION['cart'][$p['id']]);continue;}$subtotal=$q*$p['price'];$total+=$subtotal;$items[]=['p'=>$p,'q'=>$q,'subtotal'=>$subtotal];}}
require 'header.php'; ?>
<h1>Your Cart</h1><?php if(!$items):?><p>Your cart is empty. <a href="index.php">Browse shoes</a>.</p><?php else:?><div class="panel"><?php foreach($items as $it):?><div class="cartrow"><div><strong><?=e($it['p']['name'])?></strong><br><?=money($it['p']['price'])?> × <?=$it['q']?> = <?=money($it['subtotal'])?></div><form method="post"><input type="hidden" name="csrf" value="<?=csrf_token()?>"><input type="hidden" name="action" value="remove"><input type="hidden" name="product_id" value="<?=$it['p']['id']?>"><button class="danger">Remove</button></form></div><?php endforeach;?><h2>Total: <?=money($total)?></h2><a class="button" href="checkout.php">Proceed to checkout</a></div><?php endif;?>
<?php require 'footer.php'; ?>
