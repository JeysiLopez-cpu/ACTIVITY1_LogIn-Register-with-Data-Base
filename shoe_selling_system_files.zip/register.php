<?php require 'config.php';
$error='';
if ($_SERVER['REQUEST_METHOD']==='POST') { verify_csrf();
$name=trim($_POST['name']??''); $email=filter_var(trim($_POST['email']??''),FILTER_VALIDATE_EMAIL); $pw=$_POST['password']??'';
if (!$name || !$email || strlen($pw)<8) $error='Enter a name, valid email, and password of at least 8 characters.';
else { try {$s=$pdo->prepare("INSERT INTO users(name,email,password) VALUES(?,?,?)");$s->execute([$name,$email,password_hash($pw,PASSWORD_DEFAULT)]);header('Location: login.php?registered=1');exit;} catch(PDOException $e){$error='That email address is already registered.';} }
}
require 'header.php'; ?>
<h1>Create account</h1><?php if($error): ?><p class="error"><?=e($error)?></p><?php endif; ?>
<form class="panel" method="post"><input type="hidden" name="csrf" value="<?=csrf_token()?>"><label>Full name<input name="name" required></label><label>Email<input type="email" name="email" required></label><label>Password<input type="password" name="password" minlength="8" required></label><button>Create account</button></form>
<?php require 'footer.php'; ?>
