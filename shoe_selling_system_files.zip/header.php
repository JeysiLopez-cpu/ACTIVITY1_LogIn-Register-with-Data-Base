<?php $user = current_user(); ?>
<!doctype html><html lang="en"><head><meta charset="utf-8"><meta name="viewport" content="width=device-width, initial-scale=1">
<title>SoleMate Shoe Store</title><link rel="stylesheet" href="style.css"></head><body>
<header class="top"><a class="brand" href="index.php">SoleMate</a><nav>
<a href="index.php">Shop</a>
<?php if ($user): ?><a href="cart.php">Cart</a><a href="orders.php">My Orders</a>
<?php if ($user['role']==='admin'): ?><a href="admin.php">Admin</a><?php endif; ?>
<a href="logout.php">Logout (<?= e($user['name']) ?>)</a>
<?php else: ?><a href="login.php">Login</a><a href="register.php">Register</a><?php endif; ?>
</nav></header><main class="container">
