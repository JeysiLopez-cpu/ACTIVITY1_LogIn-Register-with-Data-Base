<?php require 'config.php'; require 'header.php';
$stmt = $pdo->query("SELECT * FROM products ORDER BY created_at DESC");
$products = $stmt->fetchAll(); ?>
<section class="hero"><h1>Find your next favorite pair.</h1><p>Comfort, style, and confidence in every step.</p></section>
<h2>Available Shoes</h2><div class="products">
<?php foreach ($products as $p): ?><article class="product">
<?php if ($p['image_url']): ?><img src="<?= e($p['image_url']) ?>" alt="<?= e($p['name']) ?>"><?php else: ?><div class="placeholder">SOLE MATE</div><?php endif; ?>
<h3><?= e($p['name']) ?></h3><p><?= e($p['description']) ?></p><strong><?= money($p['price']) ?></strong>
<p>Stock: <?= (int)$p['stock'] ?></p>
<?php if ($p['stock']>0): ?><form method="post" action="cart.php"><input type="hidden" name="csrf" value="<?= csrf_token() ?>"><input type="hidden" name="action" value="add"><input type="hidden" name="product_id" value="<?= (int)$p['id'] ?>"><label>Qty <input type="number" name="quantity" value="1" min="1" max="<?= (int)$p['stock'] ?>"></label><button>Add to cart</button></form><?php else: ?><span class="muted">Out of stock</span><?php endif; ?>
</article><?php endforeach; ?></div>
<?php require 'footer.php'; ?>
