<?php require 'config.php'; $error='';
if ($_SERVER['REQUEST_METHOD']==='POST') {verify_csrf();$s=$pdo->prepare("SELECT * FROM users WHERE email=?");$s->execute([trim($_POST['email']??'')]);$u=$s->fetch();
if($u && password_verify($_POST['password']??'',$u['password'])){session_regenerate_id(true);$_SESSION['user']=['id'=>$u['id'],'name'=>$u['name'],'email'=>$u['email'],'role'=>$u['role']];header('Location: index.php');exit;} $error='Incorrect email or password.';}
require 'header.php'; ?>
<h1>Login</h1><?php if(isset($_GET['registered'])):?><p class="success">Account created. You can now log in.</p><?php endif;?><?php if($error):?><p class="error"><?=e($error)?></p><?php endif;?>
<form class="panel" method="post"><input type="hidden" name="csrf" value="<?=csrf_token()?>"><label>Email<input type="email" name="email" required></label><label>Password<input type="password" name="password" required></label><button>Login</button></form>
<?php require 'footer.php'; ?>
