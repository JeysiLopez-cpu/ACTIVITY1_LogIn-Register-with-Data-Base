# SoleMate — PHP Shoe Selling System

A beginner-friendly PHP and MySQL shoe store project. Features include customer registration/login, product listing, shopping cart, checkout using Cash on Delivery, order history, stock deduction, and an admin dashboard for product and order management.

## Requirements
- XAMPP (Apache, PHP, MySQL)
- Web browser
- Git / GitHub account (optional, for submission)

## Run locally
1. Copy the `shoe_selling_system` folder into `C:\xampp\htdocs\`.
2. Open XAMPP and start **Apache** and **MySQL**.
3. Open `http://localhost/phpmyadmin`.
4. Choose **Import**, select `database.sql`, and click **Go**.
5. If your MySQL username/password is different, edit the values at the top of `config.php`.
6. Visit `http://localhost/shoe_selling_system/`.
7. Register a customer account and log in.

## Make your account an administrator
After registering, open phpMyAdmin, select the `shoe_store` database, open the SQL tab, and run this command. Replace the email with the email you registered:

```sql
UPDATE users SET role = 'admin' WHERE email = 'your@email.com';
```

Log out and log in again. The Admin link will appear in the navigation bar.

## Upload to GitHub
1. Create a new repository on GitHub.
2. Upload the contents of this folder (not just the ZIP file).
3. Make sure `README.md`, `database.sql`, and all `.php` and `.css` files are included.
4. Do not upload real passwords, private customer data, or production database backups.

## Project files
- `config.php` — database connection, sessions, helper functions
- `database.sql` — database and sample products
- `header.php`, `footer.php` — shared page layout
- `index.php` — product catalog
- `register.php`, `login.php`, `logout.php` — account features
- `cart.php`, `checkout.php` — cart and COD checkout
- `orders.php` — customer order history
- `admin.php` — product and order management
- `style.css` — page styling

## Important notes
This is a school/demo project, not a production-ready commerce platform. Before using it publicly, add stronger validation, rate limiting, secure deployment settings (HTTPS and secure cookies), image upload validation, and payment-provider integration. Test all features locally before submitting.
