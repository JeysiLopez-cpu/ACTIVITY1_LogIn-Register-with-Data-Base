<?php require 'config.php'; require_login(); if(empty($_SESSION['cart'])){header('Location: cart.php');exit;}
$error='';
if($_SERVER['REQUEST_METHOD']==='POST'){verify_csrf();$address=trim($_POST['address']??'');$phone=trim($_POST['phone']??'');
if(!$address||!$phone)$error='Please enter your delivery address and phone number.';
else try{$pdo->beginTransaction();$total=0;$cart=$_SESSION['cart'];$locked=[];
foreach($cart as $id=>$qty){$s=$pdo->prepare("SELECT * FROM products WHERE id=? FOR UPDATE");$s->execute([(int)$id]);$p=$s->fetch();if(!$p||(int)$p['stock']<(int)$qty)throw new Exception('A product is unavailable or has insufficient stock. Please update your cart.');$locked[]=['p'=>$p,'q'=>(int)$qty];$total+=$p['price']*$qty;}
$s=$pdo->prepare("INSERT INTO orders(user_id,total,address,phone) VALUES(?,?,?,?)");$s->execute([current_user()['id'],$total,$address,$phone]);$orderId=(int)$pdo->lastInsertId();
foreach($locked as $it){$p=$it['p'];$q=$it['q'];$s=$pdo->prepare("INSERT INTO order_items(order_id,product_id,product_name,quantity,price) VALUES(?,?,?,?,?)");$s->execute([$orderId,$p['id'],$p['name'],$q,$p['price']]);$s=$pdo->prepare("UPDATE products SET stock=stock-? WHERE id=?");$s->execute([$q,$p['id']]);}
$pdo->commit();unset($_SESSION['cart']);header('Location: orders.php?placed=1');exit;
}catch(Throwable $e){if($pdo->inTransaction())$pdo->rollBack();$error=$e instanceof PDOException?'Checkout failed. Please try again.':$e->getMessage();}}
require 'header.php'; ?>
<h1>Checkout</h1><?php if($error):?><p class="error"><?=e($error)?></p><?php endif;?>
<form class="panel" method="post"><input type="hidden" name="csrf" value="<?=csrf_token()?>"><label>Delivery address<textarea name="address" required></textarea></label><label>Phone number<input name="phone" required></label><label>Payment method<input value="Cash on Delivery" disabled></label><button>Place order</button></form>
<?php require 'footer.php'; ?>
